package Model;

import java.util.Objects;

/**
 * Class for a User Object
 */
public class User {
    /**
     * Unique user name(non-empty string)
     */
    String userName;
    /**
     * User's password(non-empty string)
     */
    String password;
    /**
     * User's email address(non-empty string)
     */
    String email;
    /**
     * User's First name(non-empty string)
     */
    String firstName;
    /**
     * User's Last name(non-empty string)
     */
    String lastName;
    /**
     * User's gender(string "f" or "m")
     */
    String gender;
    /**
     * Unique person ID assigned to this user's generated person object
     */
    String personID;

    public void setuserName(String UserName) {
        userName = UserName;
    }

    public void setpassword(String Password) {
        password = Password;
    }

    public void setemail(String Email) {
        email = Email;
    }

    public void setfirstName(String FirstName) {
        firstName = FirstName;
    }

    public void setlastName(String LastName) {
        lastName = LastName;
    }

    public void setgender(String Gender) {
        gender = Gender;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return userName.equals(user.userName) &&
                password.equals(user.password) &&
                email.equals(user.email) &&
                firstName.equals(user.firstName) &&
                lastName.equals(user.lastName) &&
                gender.equals(user.gender) &&
                personID.equals(user.personID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userName, password, email, firstName, lastName, gender, personID);
    }

    public void setpersonID(String PersonID) {
        personID = PersonID;
    }

    public String getuserName() {
        return userName;
    }

    public String getpassword() {
        return password;
    }

    public String getemail() {
        return email;
    }

    public String getfirstName() {
        return firstName;
    }

    public String getlastName() {
        return lastName;
    }

    public String getgender() {
        return gender;
    }

    public String getpersonID() {
        return personID;
    }

    public User(String UserName, String Password, String Email, String FirstName, String LastName, String Gender, String PersonID) {
        userName = UserName;
        password = Password;
        email = Email;
        firstName = FirstName;
        lastName = LastName;
        gender = Gender;
        personID = PersonID;
    }
}
