package Model;

import java.util.Objects;

/**
 * Class for event objects
 */
public class Event {
    /**
     * string with the eventID
     */
    private String eventID;
    /**
     *string with the username for this event
     */
    private String associatedUsername;
    /**
     *string with the personID
     */
    private String personID;
    /**
     *float of the latitude of this event
     */
    private float latitude;
    /**
     *float of the longitude of this event
     */
    private float longitude;
    /**
     * string with country name
     */
    private String country;
    /**
     *string with city name
     */
    private String city;
    /**
     *string with eventType
     */
    private String eventType;
    /**
     *int for this year
     */
    private int year;

    public String geteventID() {
        return eventID;
    }

    public void seteventID(String EventID) {
        eventID = EventID;
    }

    public String getassociatedUserName() {
        return associatedUsername;
    }

    public void setassociatedUserName(String associatedUserName) {
        associatedUsername = associatedUserName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String geteventType() {
        return eventType;
    }

    public void seteventType(String eventType) {
        eventType = eventType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Event(String eventID, String associatedUserName, String personID, float latitude, float longitude,
                 String country, String city, String eventType, int year) {
        this.eventID = eventID;
        this.associatedUsername = associatedUserName;
        this.personID = personID;
        this.latitude = latitude;
        this.longitude = longitude;
        this.country = country;
        this.city = city;
        this.eventType = eventType;
        this.year = year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return Float.compare(event.latitude, latitude) == 0 &&
                Float.compare(event.longitude, longitude) == 0 &&
                year == event.year &&
                eventID.equals(event.eventID) &&
                associatedUsername.equals(event.associatedUsername) &&
                personID.equals(event.personID) &&
                country.equals(event.country) &&
                city.equals(event.city) &&
                eventType.equals(event.eventType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventID, associatedUsername, personID, latitude, longitude, country, city, eventType, year);
    }
}
