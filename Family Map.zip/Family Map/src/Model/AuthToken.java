package Model;

import java.util.Objects;

/**
 * Class for the AuthToken
 */
public class AuthToken {
    /**
     * the UserName of the current User
     */
    String UserName;
    /**
     * the generated authToken string to return for this authToken
     */
    String AuthToken;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getAuthToken() {
        return AuthToken;
    }

    public void setAuthToken(String authToken) {
        AuthToken = authToken;
    }

    public AuthToken(String userName, String authToken) {
        UserName = userName;
        AuthToken = authToken;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthToken authToken = (AuthToken) o;
        return UserName.equals(authToken.UserName) &&
                AuthToken.equals(authToken.AuthToken);
    }

    @Override
    public int hashCode() {
        return Objects.hash(UserName, AuthToken);
    }
}
