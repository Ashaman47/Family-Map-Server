package Handlers;

import Service.Result.LoadResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonSerializer {
    public static <T> T deserialize(String value, Class<T> returnType) {
        return (new Gson()).fromJson(value, returnType);
    }
    public static <T> String serialize(T sendType){
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(sendType);
    }

}
