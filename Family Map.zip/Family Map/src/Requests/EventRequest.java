package Requests;
/**
 * Request body for the /Event API
 * Most likely empty
 */
public class EventRequest {
}
