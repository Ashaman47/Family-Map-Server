package Requests;
/**
 * Request body for the /person/[personID] API
 * Most likely empty
 */
public class PersonRequest {
}
