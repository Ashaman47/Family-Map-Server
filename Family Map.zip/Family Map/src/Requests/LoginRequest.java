package Requests;
/**
 * Request body for the /login API
 */
public class LoginRequest {
    /**
     * userName of user to be logged in
     */
    String userName;
    /**
     * password of user to be logged in
     */
    String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
