package Requests;
/**
 * Request body for the /fill API
 * Most likely empty
 */
public class FillRequest {
}
