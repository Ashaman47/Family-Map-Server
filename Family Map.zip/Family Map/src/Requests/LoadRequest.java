package Requests;
import Model.*;

import java.util.ArrayList;
/**
 * Request body for the /load API
 */
public class LoadRequest {
    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public ArrayList<Person> getPersons() {
        return persons;
    }

    public void setPersons(ArrayList<Person> persons) {
        this.persons = persons;
    }

    public ArrayList<Event> getEvents() {
        return events;
    }

    public void setEvents(ArrayList<Event> events) {
        this.events = events;
    }
    /**
     * list of all users in the database
     */
    ArrayList<User>users;
    /**
     * list of all persons in the database
     */
    ArrayList<Person>persons;
    /**
     * list of all events in the database
     */
    ArrayList<Event>events;
}
