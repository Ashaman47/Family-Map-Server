package Requests;
/**
 * Request body for the /register API
 */
public class RegisterRequest {
    /**
     * Unique user name(non-empty string)
     */
    String userName;
    /**
     * User's Password(non-empty string)
     */
    String password;
    /**
     * User's email address(non-empty string)
     */
    String email;
    /**
     * User's First name(non-empty string)
     */
    String firstName;
    /**
     * User's Last name(non-empty string)
     */
    String lastName;
    /**
     * User's gender(string "f" or "m")
     */
    String gender;
    /**
     * Unique person ID assigned to this user's generated person object
     */
    String personID;

    public String getuserName() {
        return userName;
    }

    public void setuserName(String userName) {
        userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String Email) {
        this.email = Email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
