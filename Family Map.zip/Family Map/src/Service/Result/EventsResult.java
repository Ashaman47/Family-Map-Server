package Service.Result;
import Model.*;

import java.util.ArrayList;
/**
 *The result of the /event API
 */
public class EventsResult extends Result{
    /**
     * the List of all Events that will be returned by this class.
     */
    ArrayList<Event>data;

    public ArrayList<Event> getEvents() {
        return data;
    }

    public void setEvents(ArrayList<Event> events) {
        data = events;
    }
}
