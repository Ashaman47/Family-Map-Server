package Service.Result;

import java.util.Objects;

/**
 * The result of the /Event/[eventID] API
 */
public class EventResult extends Result{

    /**
     * string with the eventID
     */
    private String eventID;

    public EventResult() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EventResult that = (EventResult) o;
        return Float.compare(that.latitude, latitude) == 0 &&
                Float.compare(that.longitude, longitude) == 0 &&
                year == that.year &&
                Objects.equals(eventID, that.eventID) &&
                Objects.equals(associatedUsername, that.associatedUsername) &&
                Objects.equals(personID, that.personID) &&
                Objects.equals(country, that.country) &&
                Objects.equals(city, that.city) &&
                Objects.equals(eventType, that.eventType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventID, associatedUsername, personID, latitude, longitude, country, city, eventType, year);
    }

    public EventResult(String EventID, String AssociatedUserName, String personID, float latitude, float longitude, String country, String city, String EventType, int year) {
        eventID = EventID;
        associatedUsername = AssociatedUserName;
        this.personID = personID;
        this.latitude = latitude;
        this.longitude = longitude;
        this.country = country;
        this.city = city;
        eventType = EventType;
        this.year = year;
    }

    /**
     *string with the username for this event
     */
    private String associatedUsername;
    /**
     *string with the personID
     */
    private String personID;
    /**
     *float of the latitude of this event
     */
    private float latitude;
    /**
     *float of the longitude of this event
     */
    private float longitude;
    /**
     * string with country name
     */
    private String country;
    /**
     *string with city name
     */
    private String city;
    /**
     *string with eventtype
     */
    private String eventType;
    /**
     *int for this year
     */
    private int year;


    public String getEventID() {
        return eventID;
    }

    public void setEventID(String EventID) {
        eventID = EventID;
    }

    public String getAssociatedUserName() {
        return associatedUsername;
    }

    public void setAssociatedUserName(String AssociatedUserName) {
        associatedUsername = AssociatedUserName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String EventType) {
        eventType = EventType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
