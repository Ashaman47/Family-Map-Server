package Service.Result;
/**
 *The result of the /Login API
 */
public class LoginResult extends Result{
    /**
     * The authToken of the User that is logging in
     */
    String authToken;
    /**
     * The userName of the current user
     */
    String userName;
    /**
     * The ID of the person related to this User
     */
    String personID;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String UserName) {
        userName = UserName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String PersonID) {
        personID = PersonID;
    }
}
