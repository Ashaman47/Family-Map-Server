package Service.Result;
import Model.*;
import java.util.ArrayList;
/**
 * The result of the /person API
 */
public class PeopleResult extends Result{
    /**
     * The list of all person objects
     */
    ArrayList<Person>data;

    public ArrayList<Person> getPeople() {
        return data;
    }

    public void setPeople(ArrayList<Person> People) {
        data = People;
    }
}
