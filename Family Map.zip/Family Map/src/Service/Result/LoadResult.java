package Service.Result;
import java.util.ArrayList;
/**
 *The Result of the /Load API
 * Most likely empty
 */
public class LoadResult extends Result{
}
