package Service.Result;
/**
 *The result of the /fill API
 * Most likely Empty
 */
public class FillResult extends Result{
}
