package Service.Result;
/**
 *The base class that all results will inherit from
 */
public class Result {
    /**
     *The success/failure message for all results
     */
    String message;
    /**
     *Boolean of success failure of each result
     */
    Boolean success;

    public String getMessage() {
        return message;
    }

    public void setMessage(String Message) {
        message = Message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean Success) {
        success = Success;
    }
}
