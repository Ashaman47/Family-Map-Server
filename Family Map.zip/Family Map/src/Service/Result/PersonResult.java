package Service.Result;
/**
 * the result of the /Person/[PersonID] API
 */
public class PersonResult extends Result{
    /**
     * The string ID associated with this person
     */
    String personID;
    /**
     * The userName of the user account this person belongs to.
     */
    String associatedUserName;
    /**
     * First Name of current person
     */
    String firstName;
    /**
     * Last Name of current person
     */
    String lastName;
    /**
     * Gender('m' or 'f')
     */
    String gender;

    public PersonResult() {
    }

    public PersonResult(String PersonID, String AssociatedUserName, String FirstName, String LastName, String Gender, String FatherID, String MotherID, String SpouseID) {
        personID = PersonID;
        associatedUserName = AssociatedUserName;
        firstName = FirstName;
        lastName = LastName;
        gender = Gender;
        fatherID = FatherID;
        motherID = MotherID;
        spouseID = SpouseID;
    }

    /**
     * Person ID of person's father(possibly null);
     */
    String fatherID;
    /**
     *  Person ID of person's mother(possibly null);
     */
    String motherID;
    /**
     *  Person ID of person's spouse(possibly null);
     */
    String spouseID;

    public String getAssociatedUserName() {
        return associatedUserName;
    }

    public void setAssociatedUserName(String AssociatedUserName) {
        associatedUserName = AssociatedUserName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String PersonID) {
        personID = PersonID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String FirstName) {
        this.firstName = FirstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String LastName) {
        this.lastName = LastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String Gender) {
        this.gender = Gender;
    }

    public String getFatherID() {
        return fatherID;
    }

    public void setFatherID(String FatherID) {
        this.fatherID = FatherID;
    }

    public String getMotherID() {
        return motherID;
    }

    public void setMotherID(String MotherID) {
        this.motherID = MotherID;
    }

    public String getSpouseID() {
        return spouseID;
    }

    public void setSpouseID(String SpouseID) {
        this.spouseID = SpouseID;
    }
}
