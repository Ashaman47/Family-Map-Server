package Service.Result;
/**
 * Class to return the result of the /clear API
 * NOTE: Most likely Empty and will not be used
 */
public class ClearResult extends Result{
}
