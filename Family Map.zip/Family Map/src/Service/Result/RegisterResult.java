package Service.Result;
/**
 *Result Class to return the /register API
 */
public class RegisterResult extends Result{
    /**
     *The authToken name to connected to the current User;
     */
    String authToken;
    /**
     *The userName of the User
     */
    String userName;
    /**
     *The ID of the User
     */
    String personID;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String UserName) {
        userName = UserName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String PersonID) {
        personID = PersonID;
    }
}
