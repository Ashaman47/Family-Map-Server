package Service;
import DAO.*;
import Model.Event;
import Model.Person;
import Requests.*;
import Service.Result.LoadResult;
import Model.*;

import java.sql.Connection;

/**
 * Clear to run the /load API
 */
public class Load {
    /**
     * Function to run the /load API
     * @param r Request body for the /load API
     */
    public LoadResult load(LoadRequest r) throws DataAccessException {
        LoadResult f = new LoadResult();
        Database db = new Database();
        try {
            int x = 0,y = 0,z = 0;

            Connection conn = db.getConnection();
            db.clearTables();
            UserDAO uDAO = new UserDAO(conn);
            for (User u : r.getUsers()) {
                uDAO.insert(u);
                x++;
            }
            PersonDAO pdao = new PersonDAO(conn);
            for (Person p : r.getPersons()) {
                pdao.insert(p);
                y++;
            }
            EventDAO edao = new EventDAO(conn);
            for (Event e : r.getEvents()) {
                edao.insert(e);
                z++;
            }
            db.closeConnection(true);
            f.setMessage("Successfully added " + x + " users, " + y + " persons, and " + z + "events.");
            f.setSuccess(Boolean.TRUE);
        } catch (DataAccessException e){
            db.closeConnection(true);
            f.setMessage(e.getMessage());
            f.setSuccess(Boolean.FALSE);

        }
        return f;
    }
}
