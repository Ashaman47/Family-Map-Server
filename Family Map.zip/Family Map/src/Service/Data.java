package Service;

import java.util.ArrayList;

public class Data {
    ArrayList<location> data = new ArrayList<>();

    public ArrayList<location> getData() {
        return data;
    }

    public void setData(ArrayList<location> data) {
        this.data = data;
    }
}
